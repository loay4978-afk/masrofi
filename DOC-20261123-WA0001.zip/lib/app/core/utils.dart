import 'package:flutter/material.dart';
import 'package:get/get.dart';

/// يحوّل النص إلى رقم (يدعم الأرقام العربية والفاصلة)
double? parseAmount(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  var r = s.trim().replaceAll('٫', '.').replaceAll(',', '.');
  for (var i = 0; i < 10; i++) {
    r = r.replaceAll(ar[i], '$i');
  }
  return double.tryParse(r);
}

String plainNumber(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toString();

void toast(String title, String msg, {bool error = false}) {
  Get.snackbar(
    title,
    msg,
    snackPosition: SnackPosition.BOTTOM,
    margin: const EdgeInsets.all(12),
    backgroundColor: error ? Colors.red.shade700 : Colors.teal.shade700,
    colorText: Colors.white,
  );
}

Future<bool> confirm(String title, String msg) async {
  final r = await Get.dialog<bool>(AlertDialog(
    title: Text(title),
    content: Text(msg),
    actions: [
      TextButton(onPressed: () => Get.back(result: false), child: const Text('إلغاء')),
      FilledButton(onPressed: () => Get.back(result: true), child: const Text('تأكيد')),
    ],
  ));
  return r ?? false;
}
