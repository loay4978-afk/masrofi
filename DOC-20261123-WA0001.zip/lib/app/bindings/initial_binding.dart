import 'package:get/get.dart';

import '../controllers/account_controller.dart';
import '../controllers/budget_controller.dart';
import '../controllers/category_controller.dart';
import '../controllers/home_controller.dart';
import '../controllers/report_controller.dart';
import '../controllers/transaction_controller.dart';

class InitialBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(HomeController(), permanent: true);
    Get.put(CategoryController(), permanent: true);
    Get.put(AccountController(), permanent: true);
    Get.put(TransactionController(), permanent: true); // قبل الميزانية والتقارير
    Get.put(BudgetController(), permanent: true);
    Get.put(ReportController(), permanent: true);
  }
}
