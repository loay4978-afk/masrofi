import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/account_controller.dart';
import '../controllers/app_controller.dart';
import '../core/constants.dart';
import '../core/utils.dart';
import '../data/models/account.dart';

class AccountsView extends StatelessWidget {
  const AccountsView({super.key});

  void _openDialog([Account? edit]) {
    final ac = Get.find<AccountController>();
    final name = TextEditingController(text: edit?.name ?? '');
    final bal = TextEditingController(text: edit == null ? '0' : plainNumber(edit.initialBalance));
    String type = edit?.type ?? 'cash';

    Get.dialog(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text(edit == null ? 'حساب جديد' : 'تعديل الحساب'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الحساب')),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: type,
              decoration: const InputDecoration(labelText: 'النوع'),
              items: [for (final e in kAccountTypes.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
              onChanged: (v) => setState(() => type = v ?? 'cash'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: bal,
              keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
              decoration: const InputDecoration(labelText: 'الرصيد الافتتاحي'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty) {
                toast('تنبيه', 'أدخل اسم الحساب', error: true);
                return;
              }
              await ac.save(Account(
                id: edit?.id,
                name: name.text.trim(),
                type: type,
                initialBalance: parseAmount(bal.text) ?? 0,
                color: kPalette[ac.accounts.length % kPalette.length],
              ));
              Get.back();
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final ac = Get.find<AccountController>();
    final app = Get.find<AppController>();
    return Scaffold(
      appBar: AppBar(title: const Text('الحسابات')),
      floatingActionButton: FloatingActionButton(onPressed: () => _openDialog(), child: const Icon(Icons.add)),
      body: Obx(() => ListView(
            padding: const EdgeInsets.only(bottom: 96),
            children: [
              ListTile(
                title: const Text('الإجمالي'),
                trailing: Text(app.fmt(ac.total), textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              ),
              const Divider(),
              for (final a in ac.accounts)
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Color(a.color).withOpacity(0.15),
                    child: Icon(kAccountIcons[a.type] ?? Icons.payments, color: Color(a.color)),
                  ),
                  title: Text(a.name),
                  subtitle: Text(kAccountTypes[a.type] ?? ''),
                  onTap: () => _openDialog(a),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(app.fmt(a.balance),
                          textDirection: TextDirection.ltr,
                          style: TextStyle(fontWeight: FontWeight.bold, color: a.balance < 0 ? Colors.red : null)),
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          if (await confirm('حذف الحساب', 'سيتم حذف الحساب "${a.name}" وكل عملياته. متأكد؟')) {
                            await ac.remove(a);
                          }
                        },
                      ),
                    ],
                  ),
                ),
            ],
          )),
    );
  }
}
