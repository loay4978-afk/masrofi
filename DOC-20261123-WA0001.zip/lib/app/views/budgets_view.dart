import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import '../controllers/budget_controller.dart';
import '../controllers/category_controller.dart';
import '../core/constants.dart';
import '../core/utils.dart';
import '../data/models/budget.dart';
import 'widgets/month_selector.dart';

class BudgetsView extends StatelessWidget {
  const BudgetsView({super.key});

  Color _barColor(double r) => r >= 1 ? Colors.red : (r >= 0.8 ? Colors.orange : Colors.green);

  void _openDialog({Budget? edit}) {
    final cc = Get.find<CategoryController>();
    final bc = Get.find<BudgetController>();
    int? catId = edit?.categoryId;
    final ctrl = TextEditingController(text: edit == null ? '' : plainNumber(edit.amount));

    Get.dialog(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text(edit == null ? 'ميزانية جديدة' : 'تعديل الميزانية'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<int>(
              value: catId,
              hint: const Text('اختر الفئة'),
              items: [for (final c in cc.expenseCats) DropdownMenuItem(value: c.id, child: Text(c.name))],
              onChanged: edit == null ? (v) => setState(() => catId = v) : null,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'الحد الشهري'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () async {
              final a = parseAmount(ctrl.text);
              if (catId == null || a == null || a <= 0) {
                toast('تنبيه', 'اختر الفئة وأدخل مبلغاً صحيحاً', error: true);
                return;
              }
              await bc.save(catId!, a);
              Get.back();
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final bc = Get.find<BudgetController>();
    final app = Get.find<AppController>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('الميزانية'),
        actions: [IconButton(icon: const Icon(Icons.add), tooltip: 'ميزانية جديدة', onPressed: () => _openDialog())],
      ),
      body: Obx(() {
        final list = bc.budgets;
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
          children: [
            const MonthSelector(),
            if (list.isEmpty)
              Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  children: [
                    const Text('لم تضع أي ميزانية بعد.\nحدّد حداً شهرياً لكل فئة لتتابع التزامك.', textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton.icon(onPressed: () => _openDialog(), icon: const Icon(Icons.add), label: const Text('إضافة ميزانية')),
                  ],
                ),
              )
            else ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('إجمالي الميزانيات'),
                      const SizedBox(height: 4),
                      Text('${app.fmt(bc.totalSpent)} من ${app.fmt(bc.totalLimit)}',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 10),
                      LinearProgressIndicator(
                        value: bc.totalLimit == 0 ? 0 : (bc.totalSpent / bc.totalLimit).clamp(0.0, 1.0),
                        minHeight: 8,
                        borderRadius: BorderRadius.circular(8),
                        color: _barColor(bc.totalLimit == 0 ? 0 : bc.totalSpent / bc.totalLimit),
                      ),
                    ],
                  ),
                ),
              ),
              for (final b in list)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 8, 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 18,
                              backgroundColor: Color(b.color).withOpacity(0.15),
                              child: Icon(iconOf(b.icon), size: 20, color: Color(b.color)),
                            ),
                            const SizedBox(width: 10),
                            Expanded(child: Text(b.categoryName, style: const TextStyle(fontWeight: FontWeight.bold))),
                            Text('${(b.ratio * 100).round()}%', style: TextStyle(color: _barColor(b.ratio), fontWeight: FontWeight.bold)),
                            PopupMenuButton<String>(
                              onSelected: (v) async {
                                if (v == 'edit') {
                                  _openDialog(edit: b);
                                } else if (await confirm('حذف الميزانية', 'حذف ميزانية ${b.categoryName}؟')) {
                                  await bc.remove(b);
                                }
                              },
                              itemBuilder: (_) => const [
                                PopupMenuItem(value: 'edit', child: Text('تعديل')),
                                PopupMenuItem(value: 'delete', child: Text('حذف')),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Padding(
                          padding: const EdgeInsetsDirectional.only(end: 8),
                          child: LinearProgressIndicator(
                            value: b.ratio.clamp(0.0, 1.0),
                            minHeight: 10,
                            borderRadius: BorderRadius.circular(8),
                            color: _barColor(b.ratio),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text('صُرف ${app.fmt(b.spent)} من ${app.fmt(b.amount)}', style: Theme.of(context).textTheme.bodySmall),
                        Text(
                          b.remaining >= 0 ? 'المتبقي ${app.fmt(b.remaining)}' : 'تجاوزت بمقدار ${app.fmt(-b.remaining)}',
                          style: TextStyle(color: b.remaining >= 0 ? Colors.green.shade700 : Colors.red, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ],
        );
      }),
    );
  }
}
