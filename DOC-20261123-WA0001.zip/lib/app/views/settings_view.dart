import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import '../controllers/transaction_controller.dart';
import '../core/constants.dart';
import '../core/utils.dart';
import '../routes/app_pages.dart';

class SettingsView extends StatelessWidget {
  const SettingsView({super.key});

  void _editName(AppController app) {
    final ctrl = TextEditingController(text: app.user.value.name);
    Get.dialog(AlertDialog(
      title: const Text('الاسم'),
      content: TextField(controller: ctrl, autofocus: true),
      actions: [
        TextButton(onPressed: () => Get.back(), child: const Text('إلغاء')),
        FilledButton(
          onPressed: () async {
            if (ctrl.text.trim().isNotEmpty) await app.updateName(ctrl.text.trim());
            Get.back();
          },
          child: const Text('حفظ'),
        ),
      ],
    ));
  }

  void _pickCurrency(AppController app) {
    Get.dialog(SimpleDialog(
      title: const Text('العملة'),
      children: [
        for (final c in kCurrencies)
          SimpleDialogOption(
            onPressed: () async {
              await app.updateCurrency(c);
              await Get.find<TransactionController>().refreshAll();
              Get.back();
            },
            child: Text(c, style: const TextStyle(fontSize: 16)),
          ),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final app = Get.find<AppController>();
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: Obx(() => ListView(
            children: [
              ListTile(
                leading: const Icon(Icons.person_outline),
                title: const Text('الاسم'),
                subtitle: Text(app.user.value.name),
                onTap: () => _editName(app),
              ),
              ListTile(
                leading: const Icon(Icons.attach_money),
                title: const Text('العملة'),
                subtitle: Text(app.user.value.currency),
                onTap: () => _pickCurrency(app),
              ),
              SwitchListTile(
                secondary: const Icon(Icons.dark_mode_outlined),
                title: const Text('الوضع الداكن'),
                value: app.themeMode.value == ThemeMode.dark,
                onChanged: app.setDark,
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.category_outlined),
                title: const Text('إدارة الفئات'),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => Get.toNamed(Routes.categories),
              ),
              ListTile(
                leading: const Icon(Icons.account_balance_wallet_outlined),
                title: const Text('الحسابات'),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => Get.toNamed(Routes.accounts),
              ),
              ListTile(
                leading: const Icon(Icons.ios_share),
                title: const Text('تصدير البيانات (CSV)'),
                onTap: () async {
                  try {
                    await Get.find<TransactionController>().exportCsv();
                  } catch (e) {
                    toast('خطأ', 'تعذّر التصدير', error: true);
                  }
                },
              ),
              const Divider(),
              const ListTile(
                leading: Icon(Icons.info_outline),
                title: Text('مصروفي'),
                subtitle: Text('الإصدار 1.0.0 • جميع بياناتك محفوظة على جهازك فقط'),
              ),
            ],
          )),
    );
  }
}
