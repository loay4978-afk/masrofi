import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/home_controller.dart';
import '../routes/app_pages.dart';
import 'budgets_view.dart';
import 'dashboard_view.dart';
import 'reports_view.dart';
import 'transactions_view.dart';

class HomeView extends StatelessWidget {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    final hc = Get.find<HomeController>();
    return Obx(() => Scaffold(
          body: IndexedStack(
            index: hc.index.value,
            children: const [DashboardView(), TransactionsView(), BudgetsView(), ReportsView()],
          ),
          floatingActionButton: FloatingActionButton(
            onPressed: () => Get.toNamed(Routes.addTransaction),
            child: const Icon(Icons.add),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: hc.index.value,
            onDestinationSelected: hc.setIndex,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
              NavigationDestination(icon: Icon(Icons.list_alt), label: 'العمليات'),
              NavigationDestination(icon: Icon(Icons.savings_outlined), selectedIcon: Icon(Icons.savings), label: 'الميزانية'),
              NavigationDestination(icon: Icon(Icons.pie_chart_outline), selectedIcon: Icon(Icons.pie_chart), label: 'التقارير'),
            ],
          ),
        ));
  }
}
