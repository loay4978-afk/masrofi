import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/transaction_controller.dart';
import 'widgets/month_selector.dart';
import 'widgets/transaction_tile.dart';

class TransactionsView extends StatelessWidget {
  const TransactionsView({super.key});

  @override
  Widget build(BuildContext context) {
    final tc = Get.find<TransactionController>();
    return Scaffold(
      appBar: AppBar(title: const Text('العمليات')),
      body: Column(
        children: [
          const MonthSelector(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              onChanged: (v) => tc.search.value = v,
              decoration: const InputDecoration(
                hintText: 'بحث بالفئة أو الملاحظة أو الحساب',
                prefixIcon: Icon(Icons.search),
                isDense: true,
              ),
            ),
          ),
          Obx(() => Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    for (final f in const [['', 'الكل'], ['expense', 'مصاريف'], ['income', 'دخل']])
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 8),
                        child: ChoiceChip(
                          label: Text(f[1]),
                          selected: tc.typeFilter.value == f[0],
                          onSelected: (_) => tc.typeFilter.value = f[0],
                        ),
                      ),
                  ],
                ),
              )),
          Expanded(
            child: Obx(() {
              final list = tc.filtered;
              if (list.isEmpty) return const Center(child: Text('لا توجد عمليات'));
              return ListView.separated(
                padding: const EdgeInsets.only(bottom: 96),
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) => TransactionTile(t: list[i]),
              );
            }),
          ),
        ],
      ),
    );
  }
}
