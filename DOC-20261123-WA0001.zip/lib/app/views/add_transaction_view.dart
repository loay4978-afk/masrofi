import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../controllers/account_controller.dart';
import '../controllers/app_controller.dart';
import '../controllers/category_controller.dart';
import '../controllers/transaction_controller.dart';
import '../core/constants.dart';
import '../core/utils.dart';
import '../data/models/transaction.dart';

class AddTransactionView extends StatefulWidget {
  const AddTransactionView({super.key});

  @override
  State<AddTransactionView> createState() => _AddTransactionViewState();
}

class _AddTransactionViewState extends State<AddTransactionView> {
  final tc = Get.find<TransactionController>();
  final cc = Get.find<CategoryController>();
  final ac = Get.find<AccountController>();

  TransactionModel? editing;
  String type = 'expense';
  int? categoryId;
  int? accountId;
  DateTime date = DateTime.now();
  final amountCtrl = TextEditingController();
  final noteCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    final arg = Get.arguments;
    if (arg is TransactionModel) {
      editing = arg;
      type = arg.type;
      categoryId = arg.categoryId;
      accountId = arg.accountId;
      date = arg.date;
      amountCtrl.text = plainNumber(arg.amount);
      noteCtrl.text = arg.note;
    } else if (ac.accounts.isNotEmpty) {
      accountId = ac.accounts.first.id;
    }
  }

  @override
  void dispose() {
    amountCtrl.dispose();
    noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final p = await showDatePicker(
      context: context,
      initialDate: date,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (p != null) setState(() => date = DateTime(p.year, p.month, p.day, date.hour, date.minute));
  }

  Future<void> _save() async {
    final amount = parseAmount(amountCtrl.text);
    if (amount == null || amount <= 0) return toast('تنبيه', 'أدخل مبلغاً صحيحاً', error: true);
    if (categoryId == null) return toast('تنبيه', 'اختر الفئة', error: true);
    if (accountId == null) return toast('تنبيه', 'اختر الحساب', error: true);
    await tc.save(TransactionModel(
      id: editing?.id,
      amount: amount,
      type: type,
      categoryId: categoryId!,
      accountId: accountId!,
      date: date,
      note: noteCtrl.text.trim(),
    ));
    Get.back();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(editing == null ? 'عملية جديدة' : 'تعديل العملية')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'expense', label: Text('مصروف'), icon: Icon(Icons.arrow_upward)),
              ButtonSegment(value: 'income', label: Text('دخل'), icon: Icon(Icons.arrow_downward)),
            ],
            selected: {type},
            onSelectionChanged: (s) => setState(() {
              type = s.first;
              categoryId = null;
            }),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: amountCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            decoration: InputDecoration(labelText: 'المبلغ', suffixText: Get.find<AppController>().user.value.currency),
          ),
          const SizedBox(height: 16),
          Text('الفئة', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 8),
          Obx(() {
            final cats = type == 'expense' ? cc.expenseCats : cc.incomeCats;
            return Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final c in cats)
                  ChoiceChip(
                    avatar: Icon(iconOf(c.icon), size: 18, color: Color(c.color)),
                    label: Text(c.name),
                    selected: categoryId == c.id,
                    onSelected: (_) => setState(() => categoryId = c.id),
                  ),
              ],
            );
          }),
          const SizedBox(height: 16),
          Obx(() => DropdownButtonFormField<int>(
                value: accountId,
                decoration: const InputDecoration(labelText: 'الحساب'),
                items: [
                  for (final a in ac.accounts) DropdownMenuItem(value: a.id, child: Text(a.name)),
                ],
                onChanged: (v) => setState(() => accountId = v),
              )),
          const SizedBox(height: 16),
          ListTile(
            shape: RoundedRectangleBorder(
              side: BorderSide(color: Theme.of(context).colorScheme.outline),
              borderRadius: BorderRadius.circular(4),
            ),
            leading: const Icon(Icons.calendar_today),
            title: Text(DateFormat('EEEE d MMMM yyyy', 'ar').format(date)),
            onTap: _pickDate,
          ),
          const SizedBox(height: 16),
          TextField(controller: noteCtrl, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)')),
          const SizedBox(height: 24),
          FilledButton.icon(onPressed: _save, icon: const Icon(Icons.check), label: const Text('حفظ')),
        ],
      ),
    );
  }
}
