import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/account_controller.dart';
import '../controllers/app_controller.dart';
import '../controllers/budget_controller.dart';
import '../controllers/home_controller.dart';
import '../controllers/transaction_controller.dart';
import '../routes/app_pages.dart';
import 'widgets/month_selector.dart';
import 'widgets/transaction_tile.dart';

class DashboardView extends StatelessWidget {
  const DashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    final tc = Get.find<TransactionController>();
    final ac = Get.find<AccountController>();
    final bc = Get.find<BudgetController>();
    final app = Get.find<AppController>();
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Obx(() => Text('أهلاً ${app.user.value.name}')),
        actions: [
          IconButton(icon: const Icon(Icons.account_balance_wallet_outlined), tooltip: 'الحسابات', onPressed: () => Get.toNamed(Routes.accounts)),
          IconButton(icon: const Icon(Icons.settings_outlined), tooltip: 'الإعدادات', onPressed: () => Get.toNamed(Routes.settings)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: tc.refreshAll,
        child: Obx(() {
          final alerts = bc.alerts;
          final recent = tc.recent;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
            children: [
              const MonthSelector(),
              // بطاقة الرصيد
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(colors: [cs.primary, cs.tertiary]),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('إجمالي الرصيد', style: TextStyle(color: cs.onPrimary.withOpacity(0.85))),
                    const SizedBox(height: 6),
                    Text(app.fmt(ac.total),
                        textDirection: TextDirection.ltr,
                        style: TextStyle(color: cs.onPrimary, fontSize: 30, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _MiniCard(title: 'الدخل', value: app.fmt(tc.income), color: Colors.green.shade600, icon: Icons.arrow_downward)),
                  const SizedBox(width: 12),
                  Expanded(child: _MiniCard(title: 'المصروف', value: app.fmt(tc.expense), color: Colors.red.shade600, icon: Icons.arrow_upward)),
                ],
              ),
              if (alerts.isNotEmpty) ...[
                const SizedBox(height: 16),
                for (final b in alerts)
                  Card(
                    color: b.ratio >= 1 ? Colors.red.shade50 : Colors.orange.shade50,
                    child: ListTile(
                      leading: Icon(Icons.warning_amber_rounded, color: b.ratio >= 1 ? Colors.red : Colors.orange),
                      title: Text(
                        b.ratio >= 1 ? 'تجاوزت ميزانية ${b.categoryName}' : 'اقتربت من حد ميزانية ${b.categoryName}',
                        style: const TextStyle(color: Colors.black87),
                      ),
                      subtitle: Text('استهلكت ${(b.ratio * 100).round()}%', style: const TextStyle(color: Colors.black54)),
                      onTap: () => Get.find<HomeController>().setIndex(2),
                    ),
                  ),
              ],
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('آخر العمليات', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  TextButton(onPressed: () => Get.find<HomeController>().setIndex(1), child: const Text('عرض الكل')),
                ],
              ),
              if (recent.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(child: Text('لا توجد عمليات هذا الشهر.\nاضغط + لإضافة أول عملية', textAlign: TextAlign.center)),
                )
              else
                Card(clipBehavior: Clip.antiAlias, child: Column(children: [for (final t in recent) TransactionTile(t: t)])),
            ],
          );
        }),
      ),
    );
  }
}

class _MiniCard extends StatelessWidget {
  final String title, value;
  final Color color;
  final IconData icon;
  const _MiniCard({required this.title, required this.value, required this.color, required this.icon});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              CircleAvatar(backgroundColor: color.withOpacity(0.15), child: Icon(icon, color: color, size: 20)),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.bodySmall),
                    Text(value,
                        textDirection: TextDirection.ltr,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontWeight: FontWeight.bold, color: color)),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}
