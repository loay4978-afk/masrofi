import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/account.dart';
import '../models/budget.dart';
import '../models/category.dart';
import '../models/transaction.dart';
import '../models/user.dart';

class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();

  Database? _db;
  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'masrofi.db');
    return openDatabase(
      path,
      version: 1,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''CREATE TABLE users(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, currency TEXT NOT NULL)''');
    await db.execute('''CREATE TABLE accounts(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, type TEXT NOT NULL,
      initial_balance REAL NOT NULL DEFAULT 0, color INTEGER NOT NULL)''');
    await db.execute('''CREATE TABLE categories(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, type TEXT NOT NULL,
      icon TEXT NOT NULL, color INTEGER NOT NULL)''');
    await db.execute('''CREATE TABLE transactions(
      id INTEGER PRIMARY KEY AUTOINCREMENT, amount REAL NOT NULL, type TEXT NOT NULL,
      category_id INTEGER NOT NULL, account_id INTEGER NOT NULL, date TEXT NOT NULL, note TEXT,
      FOREIGN KEY(category_id) REFERENCES categories(id),
      FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE)''');
    await db.execute('''CREATE TABLE budgets(
      id INTEGER PRIMARY KEY AUTOINCREMENT, category_id INTEGER NOT NULL UNIQUE, amount REAL NOT NULL,
      FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE)''');
    await db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)');
    await db.execute('CREATE INDEX idx_tx_date ON transactions(date)');

    // بيانات أولية
    await db.insert('users', {'name': 'صديقي', 'currency': 'ر.س'});
    await db.insert('accounts', {'name': 'المحفظة', 'type': 'cash', 'initial_balance': 0, 'color': 0xFF009688});
    const expense = [
      ['الطعام', 'food', 0xFFFB8C00],
      ['المواصلات', 'transport', 0xFF039BE5],
      ['التسوق', 'shopping', 0xFFD81B60],
      ['الفواتير', 'bills', 0xFF3949AB],
      ['الصحة', 'health', 0xFFE53935],
      ['التعليم', 'education', 0xFF8E24AA],
      ['الترفيه', 'entertainment', 0xFF43A047],
      ['المنزل', 'home', 0xFF6D4C41],
      ['أخرى', 'other', 0xFF757575],
    ];
    const income = [
      ['الراتب', 'salary', 0xFF2E7D32],
      ['عمل حر', 'business', 0xFF00897B],
      ['استثمار', 'invest', 0xFF1E88E5],
      ['هدايا', 'gift', 0xFFAD1457],
    ];
    for (final c in expense) {
      await db.insert('categories', {'name': c[0], 'type': 'expense', 'icon': c[1], 'color': c[2]});
    }
    for (final c in income) {
      await db.insert('categories', {'name': c[0], 'type': 'income', 'icon': c[1], 'color': c[2]});
    }
  }

  // ───────── المستخدم والإعدادات ─────────
  Future<UserModel> getUser() async {
    final d = await database;
    final r = await d.query('users', limit: 1);
    return UserModel.fromMap(r.first);
  }

  Future<void> updateUser(UserModel u) async {
    final d = await database;
    await d.update('users', u.toMap(), where: 'id = ?', whereArgs: [u.id]);
  }

  Future<String?> getSetting(String key) async {
    final d = await database;
    final r = await d.query('settings', where: 'key = ?', whereArgs: [key]);
    return r.isEmpty ? null : r.first['value'] as String?;
  }

  Future<void> setSetting(String key, String value) async {
    final d = await database;
    await d.insert('settings', {'key': key, 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ───────── الحسابات ─────────
  Future<List<Account>> getAccounts() async {
    final d = await database;
    final r = await d.rawQuery('''
      SELECT a.*, a.initial_balance + COALESCE(SUM(CASE WHEN t.type = 'income' THEN t.amount ELSE -t.amount END), 0) AS balance
      FROM accounts a LEFT JOIN transactions t ON t.account_id = a.id
      GROUP BY a.id ORDER BY a.id''');
    return r.map(Account.fromMap).toList();
  }

  Future<int> insertAccount(Account a) async => (await database).insert('accounts', a.toMap());

  Future<void> updateAccount(Account a) async =>
      (await database).update('accounts', a.toMap(), where: 'id = ?', whereArgs: [a.id]);

  Future<void> deleteAccount(int id) async =>
      (await database).delete('accounts', where: 'id = ?', whereArgs: [id]);

  // ───────── الفئات ─────────
  Future<List<CategoryModel>> getCategories() async {
    final r = await (await database).query('categories', orderBy: 'id');
    return r.map(CategoryModel.fromMap).toList();
  }

  Future<int> insertCategory(CategoryModel c) async => (await database).insert('categories', c.toMap());

  /// يرجع false إذا كانت الفئة مستخدمة في عمليات
  Future<bool> deleteCategory(int id) async {
    final d = await database;
    final n = Sqflite.firstIntValue(
        await d.rawQuery('SELECT COUNT(*) FROM transactions WHERE category_id = ?', [id]));
    if ((n ?? 0) > 0) return false;
    await d.delete('categories', where: 'id = ?', whereArgs: [id]);
    return true;
  }

  // ───────── العمليات ─────────
  Future<List<TransactionModel>> getTransactions({DateTime? from, DateTime? to, String? type}) async {
    final d = await database;
    final where = <String>[];
    final args = <Object?>[];
    if (from != null) {
      where.add('t.date >= ?');
      args.add(from.toIso8601String());
    }
    if (to != null) {
      where.add('t.date < ?');
      args.add(to.toIso8601String());
    }
    if (type != null) {
      where.add('t.type = ?');
      args.add(type);
    }
    final r = await d.rawQuery('''
      SELECT t.*, c.name AS category_name, c.icon AS category_icon, c.color AS category_color, a.name AS account_name
      FROM transactions t
      JOIN categories c ON c.id = t.category_id
      JOIN accounts a ON a.id = t.account_id
      ${where.isEmpty ? '' : 'WHERE ${where.join(' AND ')}'}
      ORDER BY t.date DESC, t.id DESC''', args);
    return r.map(TransactionModel.fromMap).toList();
  }

  Future<int> insertTransaction(TransactionModel t) async => (await database).insert('transactions', t.toMap());

  Future<void> updateTransaction(TransactionModel t) async =>
      (await database).update('transactions', t.toMap(), where: 'id = ?', whereArgs: [t.id]);

  Future<void> deleteTransaction(int id) async =>
      (await database).delete('transactions', where: 'id = ?', whereArgs: [id]);

  // ───────── الميزانيات ─────────
  Future<List<Budget>> getBudgets() async {
    final r = await (await database).rawQuery('''
      SELECT b.*, c.name AS category_name, c.icon AS category_icon, c.color AS category_color
      FROM budgets b JOIN categories c ON c.id = b.category_id ORDER BY b.id''');
    return r.map(Budget.fromMap).toList();
  }

  Future<void> upsertBudget(int categoryId, double amount) async {
    await (await database).insert('budgets', {'category_id': categoryId, 'amount': amount},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteBudget(int id) async =>
      (await database).delete('budgets', where: 'id = ?', whereArgs: [id]);
}
