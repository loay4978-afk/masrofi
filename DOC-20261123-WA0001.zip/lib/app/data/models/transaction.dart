class TransactionModel {
  final int? id;
  final double amount;
  final String type; // expense | income
  final int categoryId;
  final int accountId;
  final DateTime date;
  final String note;

  // حقول للعرض فقط (تأتي من JOIN)
  final String categoryName;
  final String categoryIcon;
  final int categoryColor;
  final String accountName;

  const TransactionModel({
    this.id,
    required this.amount,
    required this.type,
    required this.categoryId,
    required this.accountId,
    required this.date,
    this.note = '',
    this.categoryName = '',
    this.categoryIcon = 'other',
    this.categoryColor = 0xFF9E9E9E,
    this.accountName = '',
  });

  bool get isExpense => type == 'expense';

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'amount': amount,
        'type': type,
        'category_id': categoryId,
        'account_id': accountId,
        'date': date.toIso8601String(),
        'note': note,
      };

  factory TransactionModel.fromMap(Map<String, Object?> m) => TransactionModel(
        id: m['id'] as int?,
        amount: (m['amount'] as num).toDouble(),
        type: m['type'] as String,
        categoryId: m['category_id'] as int,
        accountId: m['account_id'] as int,
        date: DateTime.parse(m['date'] as String),
        note: (m['note'] as String?) ?? '',
        categoryName: (m['category_name'] as String?) ?? '',
        categoryIcon: (m['category_icon'] as String?) ?? 'other',
        categoryColor: (m['category_color'] as int?) ?? 0xFF9E9E9E,
        accountName: (m['account_name'] as String?) ?? '',
      );
}
