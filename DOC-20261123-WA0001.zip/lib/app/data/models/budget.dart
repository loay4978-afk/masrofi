class Budget {
  final int? id;
  final int categoryId;
  final double amount; // الحد الشهري
  final String categoryName;
  final String icon;
  final int color;
  final double spent; // المصروف في الشهر المختار

  const Budget({
    this.id,
    required this.categoryId,
    required this.amount,
    this.categoryName = '',
    this.icon = 'other',
    this.color = 0xFF9E9E9E,
    this.spent = 0,
  });

  double get ratio => amount <= 0 ? 0 : spent / amount;
  double get remaining => amount - spent;

  Budget withSpent(double s) => Budget(
        id: id,
        categoryId: categoryId,
        amount: amount,
        categoryName: categoryName,
        icon: icon,
        color: color,
        spent: s,
      );

  Map<String, Object?> toMap() => {if (id != null) 'id': id, 'category_id': categoryId, 'amount': amount};

  factory Budget.fromMap(Map<String, Object?> m) => Budget(
        id: m['id'] as int?,
        categoryId: m['category_id'] as int,
        amount: (m['amount'] as num).toDouble(),
        categoryName: (m['category_name'] as String?) ?? '',
        icon: (m['category_icon'] as String?) ?? 'other',
        color: (m['category_color'] as int?) ?? 0xFF9E9E9E,
      );
}
