import 'dart:io';

import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../data/db/database_helper.dart';
import '../data/models/transaction.dart';
import 'account_controller.dart';
import 'budget_controller.dart';
import 'report_controller.dart';

class TransactionController extends GetxController {
  final _db = DatabaseHelper.instance;

  final selectedMonth = DateTime(DateTime.now().year, DateTime.now().month).obs;
  final monthTx = <TransactionModel>[].obs;
  final search = ''.obs;
  final typeFilter = ''.obs; // '' = الكل

  DateTime get monthStart => selectedMonth.value;
  DateTime get monthEnd => DateTime(selectedMonth.value.year, selectedMonth.value.month + 1);

  double get income => monthTx.where((t) => !t.isExpense).fold(0.0, (s, t) => s + t.amount);
  double get expense => monthTx.where((t) => t.isExpense).fold(0.0, (s, t) => s + t.amount);
  List<TransactionModel> get recent => monthTx.take(5).toList();

  /// القائمة بعد البحث والتصفية
  List<TransactionModel> get filtered {
    final q = search.value.trim();
    return monthTx.where((t) {
      if (typeFilter.value.isNotEmpty && t.type != typeFilter.value) return false;
      if (q.isEmpty) return true;
      return t.note.contains(q) || t.categoryName.contains(q) || t.accountName.contains(q);
    }).toList();
  }

  @override
  void onInit() {
    super.onInit();
    load();
  }

  Future<void> load() async {
    monthTx.assignAll(await _db.getTransactions(from: monthStart, to: monthEnd));
  }

  Future<void> refreshAll() async {
    await Future.wait([
      load(),
      Get.find<AccountController>().load(),
      Get.find<BudgetController>().load(),
      Get.find<ReportController>().load(),
    ]);
  }

  Future<void> changeMonth(int delta) async {
    final m = selectedMonth.value;
    selectedMonth.value = DateTime(m.year, m.month + delta);
    await refreshAll();
  }

  Future<void> save(TransactionModel t) async {
    if (t.id == null) {
      await _db.insertTransaction(t);
    } else {
      await _db.updateTransaction(t);
    }
    await refreshAll();
    final m = selectedMonth.value;
    if (t.isExpense && t.date.year == m.year && t.date.month == m.month) {
      Get.find<BudgetController>().checkAlert(t.categoryId);
    }
  }

  Future<void> remove(TransactionModel t) async {
    await _db.deleteTransaction(t.id!);
    await refreshAll();
  }

  /// تصدير كل العمليات إلى ملف CSV ومشاركته
  Future<void> exportCsv() async {
    final all = await _db.getTransactions();
    final sb = StringBuffer('\uFEFF'); // BOM ليعرض Excel العربية بشكل صحيح
    sb.writeln('التاريخ,النوع,الفئة,الحساب,المبلغ,ملاحظة');
    for (final t in all) {
      sb.writeln([
        DateFormat('yyyy-MM-dd HH:mm', 'en').format(t.date),
        t.isExpense ? 'مصروف' : 'دخل',
        t.categoryName,
        t.accountName,
        t.amount,
        t.note,
      ].map(_esc).join(','));
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/masrofi_export.csv');
    await file.writeAsString(sb.toString());
    await Share.shareXFiles([XFile(file.path)], text: 'تصدير عمليات مصروفي');
  }

  String _esc(Object v) => '"${v.toString().replaceAll('"', '""')}"';
}
