import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../data/db/database_helper.dart';
import '../data/models/transaction.dart';
import 'transaction_controller.dart';

class CategoryTotal {
  final String name;
  final Color color;
  final double total;
  const CategoryTotal(this.name, this.color, this.total);
}

class MonthTrend {
  final String label;
  final double income;
  final double expense;
  const MonthTrend(this.label, this.income, this.expense);
}

class ReportController extends GetxController {
  final _db = DatabaseHelper.instance;

  final type = 'expense'.obs; // expense | income
  final expenseTotals = <CategoryTotal>[].obs;
  final incomeTotals = <CategoryTotal>[].obs;
  final trend = <MonthTrend>[].obs;

  List<CategoryTotal> get current => type.value == 'expense' ? expenseTotals : incomeTotals;
  double get currentSum => current.fold(0.0, (s, c) => s + c.total);

  @override
  void onInit() {
    super.onInit();
    load();
  }

  Future<void> load() async {
    final tc = Get.find<TransactionController>();
    final month = tc.selectedMonth.value;
    final all = await _db.getTransactions(from: DateTime(month.year, month.month - 5), to: tc.monthEnd);

    final cur = all.where((t) => !t.date.isBefore(tc.monthStart)).toList();
    expenseTotals.assignAll(_group(cur.where((t) => t.isExpense)));
    incomeTotals.assignAll(_group(cur.where((t) => !t.isExpense)));

    final months = List.generate(6, (i) => DateTime(month.year, month.month - 5 + i));
    trend.assignAll(months.map((m) {
      final inM = all.where((t) => t.date.year == m.year && t.date.month == m.month);
      return MonthTrend(
        DateFormat('MMM', 'ar').format(m),
        inM.where((t) => !t.isExpense).fold(0.0, (s, t) => s + t.amount),
        inM.where((t) => t.isExpense).fold(0.0, (s, t) => s + t.amount),
      );
    }));
  }

  List<CategoryTotal> _group(Iterable<TransactionModel> txs) {
    final map = <int, CategoryTotal>{};
    for (final t in txs) {
      final old = map[t.categoryId];
      map[t.categoryId] = CategoryTotal(t.categoryName, Color(t.categoryColor), (old?.total ?? 0) + t.amount);
    }
    return map.values.toList()..sort((a, b) => b.total.compareTo(a.total));
  }
}
