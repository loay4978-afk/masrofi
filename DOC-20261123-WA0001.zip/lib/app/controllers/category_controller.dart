import 'package:get/get.dart';

import '../core/utils.dart';
import '../data/db/database_helper.dart';
import '../data/models/category.dart';

class CategoryController extends GetxController {
  final _db = DatabaseHelper.instance;
  final categories = <CategoryModel>[].obs;

  List<CategoryModel> get expenseCats => categories.where((c) => c.type == 'expense').toList();
  List<CategoryModel> get incomeCats => categories.where((c) => c.type == 'income').toList();

  @override
  void onInit() {
    super.onInit();
    load();
  }

  Future<void> load() async => categories.assignAll(await _db.getCategories());

  Future<void> add(CategoryModel c) async {
    await _db.insertCategory(c);
    await load();
  }

  Future<void> remove(CategoryModel c) async {
    final ok = await _db.deleteCategory(c.id!);
    if (!ok) {
      toast('لا يمكن الحذف', 'هذه الفئة مستخدمة في عمليات مسجّلة', error: true);
      return;
    }
    await load();
  }
}
