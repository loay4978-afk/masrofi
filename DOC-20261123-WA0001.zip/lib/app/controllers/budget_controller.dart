import 'package:get/get.dart';

import '../core/utils.dart';
import '../data/db/database_helper.dart';
import '../data/models/budget.dart';
import 'transaction_controller.dart';

class BudgetController extends GetxController {
  final _db = DatabaseHelper.instance;
  final budgets = <Budget>[].obs;

  double get totalLimit => budgets.fold(0.0, (s, b) => s + b.amount);
  double get totalSpent => budgets.fold(0.0, (s, b) => s + b.spent);

  /// الميزانيات التي استُهلك منها 80% أو أكثر
  List<Budget> get alerts => budgets.where((b) => b.ratio >= 0.8).toList();

  @override
  void onInit() {
    super.onInit();
    load();
  }

  Future<void> load() async {
    final tc = Get.find<TransactionController>();
    final list = await _db.getBudgets();
    final txs = await _db.getTransactions(from: tc.monthStart, to: tc.monthEnd, type: 'expense');
    final spent = <int, double>{};
    for (final t in txs) {
      spent[t.categoryId] = (spent[t.categoryId] ?? 0) + t.amount;
    }
    budgets.assignAll(list.map((b) => b.withSpent(spent[b.categoryId] ?? 0)));
  }

  Future<void> save(int categoryId, double amount) async {
    await _db.upsertBudget(categoryId, amount);
    await load();
  }

  Future<void> remove(Budget b) async {
    await _db.deleteBudget(b.id!);
    await load();
  }

  /// تنبيه فوري بعد تسجيل مصروف
  void checkAlert(int categoryId) {
    final b = budgets.firstWhereOrNull((b) => b.categoryId == categoryId);
    if (b == null) return;
    if (b.ratio >= 1) {
      toast('تجاوزت الميزانية!', 'تجاوزت ميزانية ${b.categoryName} بمقدار ${plainNumber(-b.remaining)}', error: true);
    } else if (b.ratio >= 0.8) {
      toast('انتبه', 'استهلكت ${(b.ratio * 100).round()}% من ميزانية ${b.categoryName}');
    }
  }
}
