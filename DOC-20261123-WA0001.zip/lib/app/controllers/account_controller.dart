import 'package:get/get.dart';

import '../core/utils.dart';
import '../data/db/database_helper.dart';
import '../data/models/account.dart';
import 'transaction_controller.dart';

class AccountController extends GetxController {
  final _db = DatabaseHelper.instance;
  final accounts = <Account>[].obs;

  double get total => accounts.fold(0.0, (s, a) => s + a.balance);

  @override
  void onInit() {
    super.onInit();
    load();
  }

  Future<void> load() async => accounts.assignAll(await _db.getAccounts());

  Future<void> save(Account a) async {
    if (a.id == null) {
      await _db.insertAccount(a);
    } else {
      await _db.updateAccount(a);
    }
    await load();
  }

  Future<void> remove(Account a) async {
    if (accounts.length <= 1) {
      toast('تنبيه', 'يجب أن يبقى حساب واحد على الأقل', error: true);
      return;
    }
    await _db.deleteAccount(a.id!);
    await Get.find<TransactionController>().refreshAll();
  }
}
