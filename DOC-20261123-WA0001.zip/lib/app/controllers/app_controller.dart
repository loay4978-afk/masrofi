import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../data/db/database_helper.dart';
import '../data/models/user.dart';

/// الإعدادات العامة: المستخدم + العملة + المظهر
class AppController extends GetxController {
  final _db = DatabaseHelper.instance;
  final user = const UserModel(name: '', currency: 'ر.س').obs;
  final themeMode = ThemeMode.light.obs;

  Future<void> load() async {
    user.value = await _db.getUser();
    themeMode.value = (await _db.getSetting('theme')) == 'dark' ? ThemeMode.dark : ThemeMode.light;
  }

  String fmt(double v) => '${NumberFormat('#,##0.##', 'en').format(v)} ${user.value.currency}';

  Future<void> updateName(String name) async {
    user.value = user.value.copyWith(name: name);
    await _db.updateUser(user.value);
  }

  Future<void> updateCurrency(String c) async {
    user.value = user.value.copyWith(currency: c);
    await _db.updateUser(user.value);
  }

  Future<void> setDark(bool dark) async {
    themeMode.value = dark ? ThemeMode.dark : ThemeMode.light;
    Get.changeThemeMode(themeMode.value);
    await _db.setSetting('theme', dark ? 'dark' : 'light');
  }
}
