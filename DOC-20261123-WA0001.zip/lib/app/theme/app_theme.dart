import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData _build(Brightness b) => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal, brightness: b),
        appBarTheme: const AppBarTheme(centerTitle: true),
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      );
  static final light = _build(Brightness.light);
  static final dark = _build(Brightness.dark);
}
