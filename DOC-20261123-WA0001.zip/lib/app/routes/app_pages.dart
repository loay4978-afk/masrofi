import 'package:get/get.dart';

import '../views/accounts_view.dart';
import '../views/add_transaction_view.dart';
import '../views/categories_view.dart';
import '../views/home_view.dart';
import '../views/settings_view.dart';

abstract class Routes {
  static const home = '/';
  static const addTransaction = '/add-transaction';
  static const accounts = '/accounts';
  static const settings = '/settings';
  static const categories = '/categories';
}

class AppPages {
  static final pages = <GetPage>[
    GetPage(name: Routes.home, page: () => const HomeView()),
    GetPage(name: Routes.addTransaction, page: () => const AddTransactionView()),
    GetPage(name: Routes.accounts, page: () => const AccountsView()),
    GetPage(name: Routes.settings, page: () => const SettingsView()),
    GetPage(name: Routes.categories, page: () => const CategoriesView()),
  ];
}
