import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'app/bindings/initial_binding.dart';
import 'app/controllers/app_controller.dart';
import 'app/data/db/database_helper.dart';
import 'app/routes/app_pages.dart';
import 'app/theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ar');
  await DatabaseHelper.instance.database;
  final app = Get.put(AppController(), permanent: true);
  await app.load();
  runApp(const MasrofiApp());
}

class MasrofiApp extends StatelessWidget {
  const MasrofiApp({super.key});

  @override
  Widget build(BuildContext context) {
    final app = Get.find<AppController>();
    return GetMaterialApp(
      title: 'مصروفي',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: app.themeMode.value,
      locale: const Locale('ar'),
      fallbackLocale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      initialBinding: InitialBinding(),
      initialRoute: Routes.home,
      getPages: AppPages.pages,
    );
  }
}
