# مصروفي — تطبيق إدارة المصاريف (Flutter + GetX + SQLite)

## التشغيل
```bash
cd masrofi
flutter create . --project-name masrofi --org com.example   # لتوليد android/ios (إن استبدل test/widget_test.dart احذف الاختبار الافتراضي)
flutter pub get
flutter test
flutter run
```

## بناء نسخة للنشر المحلي
```bash
flutter build apk --release          # build/app/outputs/flutter-apk/app-release.apk
flutter build appbundle --release    # للنشر على Google Play
```
> للنشر الفعلي: غيّر applicationId، وأضف أيقونة التطبيق، ووقّع الـ APK بمفتاح خاص.

## البنية
```
lib/
├─ main.dart
└─ app/
   ├─ bindings/      initial_binding.dart
   ├─ controllers/   app, home, category, account, transaction, budget, report
   ├─ core/          constants.dart, utils.dart
   ├─ data/
   │  ├─ db/         database_helper.dart (SQLite)
   │  └─ models/     user, account, category, transaction, budget
   ├─ routes/        app_pages.dart
   ├─ theme/         app_theme.dart
   └─ views/         الشاشات + widgets/
```
