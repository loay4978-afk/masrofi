import 'package:flutter_test/flutter_test.dart';
import 'package:masrofi/app/data/models/account.dart';

void main() {
  test('Account balance defaults to zero', () {
    const a = Account(name: 'نقدي', type: 'cash');
    expect(a.balance, 0);
  });
}
