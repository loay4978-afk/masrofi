import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import '../controllers/report_controller.dart';
import '../controllers/transaction_controller.dart';
import 'widgets/month_selector.dart';

class ReportsView extends StatelessWidget {
  const ReportsView({super.key});

  @override
  Widget build(BuildContext context) {
    final rc = Get.find<ReportController>();
    final app = Get.find<AppController>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('التقارير'),
        actions: [
          IconButton(
            icon: const Icon(Icons.ios_share),
            tooltip: 'تصدير CSV',
            onPressed: () => Get.find<TransactionController>().exportCsv(),
          ),
        ],
      ),
      body: Obx(() {
        final data = rc.current;
        final sum = rc.currentSum;
        final isExpense = rc.type.value == 'expense';
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
          children: [
            const MonthSelector(),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'expense', label: Text('المصاريف')),
                ButtonSegment(value: 'income', label: Text('الدخل')),
              ],
              selected: {rc.type.value},
              onSelectionChanged: (s) => rc.type.value = s.first,
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(isExpense ? 'توزيع المصاريف حسب الفئة' : 'توزيع الدخل حسب المصدر',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),
                    if (data.isEmpty)
                      const Padding(padding: EdgeInsets.all(32), child: Text('لا توجد بيانات لهذا الشهر'))
                    else ...[
                      SizedBox(
                        height: 200,
                        child: PieChart(PieChartData(
                          sectionsSpace: 2,
                          centerSpaceRadius: 42,
                          sections: [
                            for (final c in data)
                              PieChartSectionData(
                                value: c.total,
                                color: c.color,
                                radius: 60,
                                title: c.total / sum >= 0.06 ? '${(c.total / sum * 100).round()}%' : '',
                                titleStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
                              ),
                          ],
                        )),
                      ),
                      const SizedBox(height: 12),
                      for (final c in data)
                        ListTile(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          leading: CircleAvatar(radius: 7, backgroundColor: c.color),
                          title: Text(c.name),
                          trailing: Text('${app.fmt(c.total)}  (${(c.total / sum * 100).toStringAsFixed(1)}%)',
                              textDirection: TextDirection.ltr),
                        ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text('الدخل مقابل المصروف (آخر 6 أشهر)',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const CircleAvatar(radius: 6, backgroundColor: Colors.green),
                      const SizedBox(width: 4),
                      const Text('دخل'),
                      const SizedBox(width: 16),
                      const CircleAvatar(radius: 6, backgroundColor: Colors.red),
                      const SizedBox(width: 4),
                      const Text('مصروف'),
                    ]),
                    const SizedBox(height: 16),
                    SizedBox(height: 220, child: _TrendChart(trend: rc.trend.toList())),
                  ],
                ),
              ),
            ),
          ],
        );
      }),
    );
  }
}

class _TrendChart extends StatelessWidget {
  final List<MonthTrend> trend;
  const _TrendChart({required this.trend});

  @override
  Widget build(BuildContext context) {
    if (trend.isEmpty) return const SizedBox();
    final maxV = trend.fold<double>(0, (m, t) => [m, t.income, t.expense].reduce((a, b) => a > b ? a : b));
    return Directionality(
      textDirection: TextDirection.ltr,
      child: BarChart(BarChartData(
        maxY: maxV == 0 ? 100 : maxV * 1.2,
        gridData: const FlGridData(show: false),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (v, meta) {
                final i = v.toInt();
                if (i < 0 || i >= trend.length) return const SizedBox();
                return SideTitleWidget(axisSide: meta.axisSide, child: Text(trend[i].label, style: const TextStyle(fontSize: 11)));
              },
            ),
          ),
        ),
        barGroups: [
          for (var i = 0; i < trend.length; i++)
            BarChartGroupData(x: i, barsSpace: 4, barRods: [
              BarChartRodData(toY: trend[i].income, color: Colors.green, width: 10, borderRadius: BorderRadius.circular(3)),
              BarChartRodData(toY: trend[i].expense, color: Colors.red, width: 10, borderRadius: BorderRadius.circular(3)),
            ]),
        ],
      )),
    );
  }
}
